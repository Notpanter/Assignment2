package ttt

type Wrapper interface {
	GetPrice() float64
}
