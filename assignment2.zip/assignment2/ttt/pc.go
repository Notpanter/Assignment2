package ttt

type BasePc struct {
}

func (pc BasePc) GetPrice() float64 {
	return 10.0
}
